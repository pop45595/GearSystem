﻿namespace GearSystem
{
    public interface IGear
    {
        int getGearID();
        IState[] getAllState();
    }
}
