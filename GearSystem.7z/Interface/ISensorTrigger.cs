﻿namespace GearSystem.Interface {
    public interface ISensorTrigger {
        void setSensor(ISensor _sensor);
    }
}
