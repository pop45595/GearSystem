﻿namespace GearSystem
{
    public interface IRule
    {
        int[] searchById(int _iId);
    }
}
